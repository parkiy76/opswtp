package com.work.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.work.dto.Member;

import javafx.scene.control.Alert;

public class FindServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public ServletContext application;
	public ArrayList<Member> list;
	
	public void init() {
		application = getServletContext();
		list = (ArrayList<Member>)application.getAttribute("list");
		System.out.println("로그인 서블릿 초기화 회원 인원수 : " + list.size());
	}


protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	request.setCharacterEncoding("utf-8");
	String name = request.getParameter("name").trim();
	String email = request.getParameter("email").trim();
	
	String message = null;
	Member dto = null;
	boolean isFind = false;
	for (int index = 0; index < list.size(); index++) {
		dto = list.get(index);
		if (dto.getName().equals(name) && dto.getEmail().equals(email)) {
			isFind = true;
			break;
			}
		}
	if(isFind) {
		response.sendRedirect("succes.jsp");
	
	}else {
		System.out.println("<script>alert('정보가 일치하지 않습니다.');</script>");

	}
	
}	
}
