package com.work.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



public class logOutservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
		

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		HttpSession session = request.getSession(false);
		
		if(session != null) {
		System.out.println("로그아웃 세션 신규 여부 : " + session.isNew());
		System.out.println("로그아웃 세션 아이디 : " + session.getId());
		
		session.removeAttribute("dto");
		session.removeAttribute("memberId");
		session.removeAttribute("name");
		session.removeAttribute("grade");
			
		session.invalidate();
		response.sendRedirect("index.jsp");
		
		}else {
			request.setAttribute("message", "로그아웃은 로그인 후");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/faill.jsp");
			dispatcher.forward(request, response);
					
		}
	}
}

