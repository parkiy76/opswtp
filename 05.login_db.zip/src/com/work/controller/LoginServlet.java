package com.work.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.work.dto.Member;
import com.work.model.dao.MemberDao;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 1
		request.setCharacterEncoding("utf-8");
		String memberId = request.getParameter("memberId").trim();
		String memberPw = request.getParameter("memberPw").trim();
		
		System.out.println("로그인정보 : " + memberId + ", " + memberPw);
		
		MemberDao dao = new MemberDao();
		
		Member dto = dao.login(memberId, memberPw);
		
		if(dto != null) {		
			HttpSession session = request.getSession(true);
			session.setAttribute("dto", dto);
			
			session.setAttribute("memberId", dto.getMemberId());
			session.setAttribute("name", dto.getName());
			session.setAttribute("grade", dto.getGrade());
			
			response.sendRedirect("mainService.jsp");
			
			
		}else {
			request.setAttribute("message", "실패");
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("/fail.jsp");
			dispatcher.forward(request, response);	
		}
	}
		
}




