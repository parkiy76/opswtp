package com.work.dto;

public class Member {
	// 1. private 멤버변수
	private String memberId = "guest";
	private String memberPw;
	private String name;
	private String phone;
	private String email;
	private String entryDate;
	private String grade;
	private int point;
	private String manager;
	
	public Member() {
	}
	
	public Member(String memberId, String memberPw, String name, String phone, String email) {
		this.memberId = memberId;
		this.memberPw = memberPw;
		this.name = name;
		this.phone = phone;
		this.email = email;
	}
	
	public Member(String memberId, String memberPw, String name, String phone, String email, 
			String entryDate, String grade, int point, String manager) {
		this(memberId, memberPw, name, phone, email);	// 다른 생성자 먼저 수행

		this.entryDate = entryDate;
		this.grade = grade;
		this.point = point;
		this.manager = manager;
	}
	
	public String getMemberId() {
		return memberId;
	}

	private boolean isMemberId(String memberId) {
		int length = memberId.length();
		
		if(length >= 6 && length <= 12) {
			return true;
		}
		return false;
	}
	
	public void setMemberId(String memberId) {
		
		boolean result = isMemberId(memberId);
		
		if (result) {
			this.memberId = memberId;
		} else {
			System.out.println("[오류] 아이디는 6자리 ~ 12자리 이내로 입력하세요");
		}
	}

	public String getMemberPw() {
		return memberPw;
	}

	public void setMemberPw(String memberPw) {
		this.memberPw = memberPw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public int getPoint() {
		return point;
	}

	public void setPoint(int point) {
		this.point = point;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	@Override
	public String toString() {
		return memberId + ", " + memberPw + ", " + name + ", " + phone + ", " + email + ", " + entryDate + ", " + grade
				+ ", " + point + ", " + manager;
	}
	
}















