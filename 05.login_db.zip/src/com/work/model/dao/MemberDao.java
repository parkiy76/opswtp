package com.work.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.work.dto.Member;

/*
	예제코드 : Web DataSource Programming 
	-- 참고 : context.xml
*/
public class MemberDao {
	public DataSource ds;
	
	public MemberDao() {
		try {
			ds = (DataSource)new InitialContext().lookup("java:comp/env/jdbc/Oracle");
			System.out.println("DataSource : " + ds);
		} catch (NamingException e) {
			System.out.println("DataSource lookup error");
			e.printStackTrace();
		}
	}
	
	
	public Member login(String memberId, String memberPw) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM MEMBER WHERE MEMBER_ID=? AND MEMBER_PW=?";
		
		try {
			conn = ds.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, memberId);
			pstmt.setString(2, memberPw);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				//String memberId = rs.getNString("member_id");
				//String memberPw = rs.getNString("member_pw");
				String name = rs.getString("name");
				String phone = rs.getString("phone");
				String email = rs.getString("email");
				String entryDate = rs.getString("entry_Date");
				String grade = rs.getString("grade");
				int point = rs.getInt("point");
				String manager = rs.getNString("manager");
				
				Member dto = new Member(memberId, memberPw, name, phone, email, entryDate, grade, point, manager);
				return dto;
			} else {
				return null;
			}
			
		} catch(SQLException e) {
			System.out.println("로그인 오류");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return null;
	}
	
}
