package com.work.jdbc.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.work.dto.Member;

/*
	예제코드 : JDBC Programming 
*/
public class MemberDaoJdbcTest {
	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = "jdbc:oracle:thin:@127.0.0.1:1521:XE";
	private String user = "student";
	private String password = "tiger";
		
	public Member login(String memberId, String memberPw) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM MEMBER WHERE MEMBER_ID=? AND MEMBER_PW=?";
		try {
			try {
				Class.forName(driver);
			} catch (ClassNotFoundException e) {
				System.out.println("JDBC Driver 로딩 오류");
				e.printStackTrace();
			}
			conn = DriverManager.getConnection(url, user, password);
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setNString(1, memberId);
			pstmt.setNString(2, memberPw);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				//String memberId = rs.getNString("member_id");
				//String memberPw = rs.getNString("member_pw");
				String name = rs.getNString("name");
				String phone = rs.getNString("phone");
				String email = rs.getNString("email");
				String entryDate = rs.getNString("entry_Date");
				String grade = rs.getNString("grade");
				int point = rs.getInt("point");
				String manager = rs.getNString("manager");
				
				Member dto = new Member(memberId, memberPw, name, phone, email, entryDate, grade, point, manager);
				return dto;
			} else {
				return null;
			}
			
		} catch(SQLException e) {
			System.out.println("로그인 오류");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return null;
	}
	
	public static void main(String[] args) {
		MemberDaoJdbcTest dao = new MemberDaoJdbcTest();
		Member dto = dao.login(args[0], args[1]);
		System.out.println(dto);
	}
}
