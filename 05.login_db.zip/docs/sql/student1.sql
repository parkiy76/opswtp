create table member (
	member_id varchar2(20) primary key, 
	member_pw varchar2(20) not null, 
	name varchar2(30) not null, 
	phone varchar2(13) not null, 
	email varchar2(40) not null, 
	entry_date varchar2(10) not null, 
	grade varchar2(1) not null, 
	point number(6),
	manager varchar2(30)
);

create table notice (
	notice_no number(3),
	title varchar2(100) not null,
	contents varchar2(500),
	write_date date,
	member_id varchar2(20),
	hit_count number default 0
);


insert into member
values('user01', 'password01', '홍길동', '010-1234-1000', 'user01@work.com', '2020.01.20', 'G', 10000, null);

insert into member
values('user02', 'password02', '강감찬', '010-1234-2000', 'user02@work.com', '2020.02.21', 'G', 50000, null);

insert into member
values('user03', 'password03', '이순신', '010-1234-3000', 'user03@work.com', '2020.03.22', 'S', null, '강동원');

insert into member
values('user04', 'password04', '김유신', '010-1234-4000', 'user04@work.com', '2020.04.23', 'S', null, '아이유');

insert into member
values('user05', 'password05', '유관순', '010-1234-5000', 'user05@work.com', '2020.05.24', 'A', null, null);

select * from member;

insert into notice
values(1, '1', '1.', to_date('2020.07.21', 'yyyy.mm.dd'), 'user01');

insert into notice
values(2, '2', '2.', to_date('2020.07.22', 'yyyy.mm.dd'), 'user02', 3);

insert into notice
values(3, '3', '3', to_date('2020.08.01', 'yyyy.mm.dd'), 'user03', 10);

insert into notice
values(4, '4', '4.', to_date('2020.08.02', 'yyyy.mm.dd'), 'user04', 2);

insert into notice
values(5, '5', '5.', SYSDATE, 'user02', 1);

insert into notice
values(6, '6', null, SYSDATE, 'user02', 0);

select * from notice;

SELECT * FROM member  
WHERE member_id=' ' AND member_pw='password01';

SELECT MEMBER_ID 
FROM MEMBER
WHERE NAME='XXXX' AND PHONE='YYYY';

SELECT MEMBER_PW 
FROM MEMBER
WHERE MEMBER_ID ='XXXX' AND PHONE='YYYY';



 SELECT * from member;
