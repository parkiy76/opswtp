package com.work.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.work.model.dto.Member;

/*
	예제코드 : Web DataSource Programming 
	-- 참고 : context.xml
*/
public class MemberDao {
	// 톰캣서버 구동시에 데이터베이스 연결(connection) pool 객체
	public DataSource ds;
	
	public MemberDao() {
		try {
			ds = (DataSource)new InitialContext().lookup("java:comp/env/jdbc/Oracle");
		} catch (NamingException e) {
			System.out.println("DataSource lookup error");
			e.printStackTrace();
		}
	}
	
	/**  
	 * 로그인
	 * @param memberId 아이디
	 * @param memberPw 비밀번호
	 * @return 회원객체, 미존재시 null
	 */
	public Member login(String memberId, String memberPw) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM MEMBER WHERE MEMBER_ID=? AND MEMBER_PW=?";
		try {
			conn = ds.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setNString(1, memberId);
			pstmt.setNString(2, memberPw);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				//String memberId = rs.getString("member_id");
				//String memberPw = rs.getString("member_pw");
				String name = rs.getString("name");
				String phone = rs.getString("phone");
				String email = rs.getString("email");
				String entryDate = rs.getString("entry_Date");
				String grade = rs.getString("grade");
				int point = rs.getInt("point");
				String manager = rs.getString("manager");
				
				Member dto = new Member(memberId, memberPw, name, phone, email, entryDate, grade, point, manager);
				return dto;
			} else {
				return null;
			}
			
		} catch(SQLException e) {
			System.out.println("로그인 오류");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return null;
	}

	/**
	 * 아이디찾기
	 * @param name 이름
	 * @param phone 휴대폰
	 * @return 아이디, 미존재시 null
	 */
	public String selectFindMemberId(String name, String phone) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT MEMBER_ID FROM MEMBER WHERE NAME=? AND PHONE=?";
		try {
			conn = ds.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setNString(1, name);
			pstmt.setNString(2, phone);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				return rs.getString("member_id");
			} else {
				return null;
			}
			
		} catch(SQLException e) {
			System.out.println("아이디찾기 오류");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return null;	
	}


	public String selectFindMemberPw(String memberId, String name, String phone) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT member_pw FROM MEMBER WHERE member_id=? AND NAME=? AND PHONE=?";
		try {
			conn = ds.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setNString(1, memberId);
			pstmt.setNString(2, name);
			pstmt.setNString(3, phone);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				return rs.getString("member_pw");
			} else {
				return null;
			}
			
		} catch(SQLException e) {
			System.out.println("비밀번호찾기 오류");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return null;		
	}

	/** 회원 추가 */
	public boolean insertMember(Member dto) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "insert into member values(?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		try {
			conn = ds.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getMemberId());
			pstmt.setString(2, dto.getMemberPw());
			pstmt.setString(3, dto.getName());
			pstmt.setString(4, dto.getPhone());
			pstmt.setString(5, dto.getEmail());
			pstmt.setString(6, dto.getEntryDate());
			pstmt.setString(7, dto.getGrade());
			pstmt.setInt(8, dto.getPoint());
			pstmt.setString(9, dto.getManager());
			
			int rows = pstmt.executeUpdate();
			
			if (rows == 1) {
				return true;
			} else {
				return false;
			}
			
		} catch(SQLException e) {
			System.out.println("로그인 오류");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return false;
	}
	
	/**
	 * 회원상세조회 : 
	 * -- select * from member where member_id = 'test01'
	 * 
	 * => 로그인 회원 : 내정보조회 (로그인 사용자 세션설정 아이디 가져오기) 
	 * => 관리자 : 회원 상세조회 (관리자 선택한 회원 아이디 가져오기)
	 * 
	 * @param memberId
	 * @return
	 */
	public Member selectOne(String memberId) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from member where member_id = ?";
		try {
			conn = ds.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, memberId);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				//String memberId = rs.getString("member_id");
				String memberPw = rs.getString("member_pw");
				String name = rs.getString("name");
				String phone = rs.getString("phone");
				String email = rs.getString("email");
				String entryDate = rs.getString("entry_Date");
				String grade = rs.getString("grade");
				int point = rs.getInt("point");
				String manager = rs.getString("manager");
				
				return new Member(memberId, memberPw, name, phone, email, entryDate, grade, point, manager);
			} 
			
		} catch(SQLException e) {
			System.out.println("내정보조회 오류");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return null;		
	}

	/**
	 * 암호변경
	 * 	-- update member set member_pw='happyday2020' where member_id='test01' and member_pw='password01'
	 * 	
	 * @param memberId
	 * @param memberPw
	 * @param modifyMemberPw
	 * @return
	 */
	public boolean updateMemberPw(String memberId, String memberPw, String modifyMemberPw) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "update member set member_pw=? where member_id=? and member_pw=?";
		
		try {
			conn = ds.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, modifyMemberPw);
			pstmt.setString(2, memberId);
			pstmt.setString(3, memberPw);
			
			int rows = pstmt.executeUpdate();
			
			if (rows == 1) {
				return true;
			} 
			
		} catch(SQLException e) {
			System.out.println("암호변경 오류");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return false;
	}

	/**
	 * 회원전체조회
	 * -- SELECT * FROM MEMBER
	 * 
	 * @return 전체회원 ArrayList<Member> Collection
	 */
	public ArrayList<Member> selectList() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM MEMBER";
		ArrayList<Member> list = new ArrayList<Member>();
		
		try {
			conn = ds.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				String memberId = rs.getString("member_id");
				String memberPw = rs.getString("member_pw");
				String name = rs.getString("name");
				String phone = rs.getString("phone");
				String email = rs.getString("email");
				String entryDate = rs.getString("entry_Date");
				String grade = rs.getString("grade");
				int point = rs.getInt("point");
				String manager = rs.getString("manager");
				
				list.add(new Member(memberId, memberPw, name, phone, email, entryDate, grade, point, manager));
			} 
			
			return list;
			
		} catch(SQLException e) {
			System.out.println("내정보조회 오류");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return list;		
	}
	
	/**
	 * 등급별 회원 전체조회
	 * @param grade 회원등급
	 * @return 해당회원전체조회
	 */
	public ArrayList<Member> selectListByGrade(String grade) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM MEMBER where grade=?";
		ArrayList<Member> list = new ArrayList<Member>();
		
		try {
			conn = ds.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, grade);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				String memberId = rs.getString("member_id");
				String memberPw = rs.getString("member_pw");
				String name = rs.getString("name");
				String phone = rs.getString("phone");
				String email = rs.getString("email");
				String entryDate = rs.getString("entry_Date");
//				String grade = rs.getString("grade");
				int point = rs.getInt("point");
				String manager = rs.getString("manager");
				
				list.add(new Member(memberId, memberPw, name, phone, email, entryDate, grade, point, manager));
			} 
			
		} catch(SQLException e) {
			System.out.println("내정보조회 오류");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return list;		
	}
	

	/**
	 * 내정보변경
	 * @param memberId 아이디
	 * @param memberPw 비밀번호
	 * @param name 이름
	 * @param phone 휴대폰
	 * @param email 이메일
	 * @return
	 */
	public boolean updateMyInfo(String memberId, String memberPw, String name, String phone, String email) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "update member set member_pw=?, name=?, phone=?, email=? where member_id=?";
		
		try {
			conn = ds.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, memberPw);
			pstmt.setString(2, name);
			pstmt.setString(3, phone);
			pstmt.setString(4, email);
			pstmt.setString(5, memberId);
			
			int rows = pstmt.executeUpdate();
			
			if (rows == 1) {
				return true;
			} 
			
		} catch(SQLException e) {
			System.out.println("내정보변경 오류");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return false;
	}
}
