package com.work.model.biz;

import java.util.ArrayList;

import com.work.model.dao.MemberDao;
import com.work.model.dto.Member;

/**
 * 회원을 관리하기 위한 업무처리 로직을 담당하는 클래스
 * -- 로그인
 * -- 로그아웃
 * -- 아이디찾기
 * -- 회원가입
 * ...
 */
public class MemberManagement {
	/** 회원 테이블에 대한 crud dao 클래스 생성 */
	private MemberDao dao = new MemberDao();
	
	/**
	 * 로그인
	 * @param memberId 아이디
	 * @param memberPw 비밀번호
	 * @return 해당회원객체, 미존재시 null
	 */
	public Member login(String memberId, String memberPw) {
		// 로그인에 대한 업무 처리 로직이 추가 : 일반, 포인트 100,000 이상여부 체킹 => 우수회원등업처리 로직
		return dao.login(memberId, memberPw);
	}

	/**
	 * 아이디 찾기
	 * @param name 이름 
	 * @param phone 휴대폰
	 * @return 회원아이디, 미존재시 null
	 */
	public String getFindMemberId(String name, String phone) {
		return dao.selectFindMemberId(name, phone);
	}

	/** 회원 등록 */
	public boolean addMember(Member dto) {
		dto.setEntryDate("2020.08.10");	// Utility 클래스 메서드 구현해서 오늘날짜 가져와서 설정 추가 구현
		dto.setGrade("G");
		dto.setPoint(1000);
		
		boolean result = dao.insertMember(dto);
		
		return result;
	}

	/** 회원 상세 조회 */
	public Member getMember(String memberId) {
		return dao.selectOne(memberId);
	}

	/** 회원 전체 조회 */
	public ArrayList<Member> getMemberList() {
		return dao.selectList();
	}

	/** 비밀번호 변경 */
	public boolean myInfoMemberPw(String memberId, String memberPw, String modifyMemberPw) {
		return dao.updateMemberPw(memberId, memberPw, modifyMemberPw);
	}
	
	/** 내정보 변경 저장 */
	public boolean setMyInfo(String memberId, String memberPw, String name, String phone, String email) {
		return dao.updateMyInfo(memberId, memberPw, name, phone, email);
	}
	
	
}










