package com.work.model.dto;

/** Encapsulation(은닉성) 반영 설계 */
public class Member {
	private String memberId = "guest";
	private String memberPw;
	private String name;
	private String phone;
	private String email;
	private String entryDate;
	private String grade;
	private int point;
	private String manager;
	
	/** 기본생성자 */
	public Member() {}
	
	/** 회원등록시 필수 데이터 초기화 생성자 : 아이디, 비밀번호, 이름, 휴대폰, 이메일 */
	public Member(String memberId, String memberPw, String name, String phone, String email) {
		this.memberId = memberId;
		this.memberPw = memberPw;
		this.name = name;
		this.phone = phone;
		this.email = email;
	}
	
	/** 실습: 회원의 전체데이터 초기화 생성자  : 아이디, 비밀번호, 이름, 휴대폰, 이메일  + 가입일, 등급, 포인트, 담당자 */
	public Member(String memberId, String memberPw, String name, String phone, String email, 
			String entryDate, String grade, int point, String manager) {
		this(memberId, memberPw, name, phone, email);	// 다른 생성자 먼저 수행
		this.entryDate = entryDate;
		this.grade = grade;
		this.point = point;
		this.manager = manager;
	}
	
	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getMemberPw() {
		return memberPw;
	}

	public void setMemberPw(String memberPw) {
		this.memberPw = memberPw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public int getPoint() {
		return point;
	}

	public void setPoint(int point) {
		this.point = point;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(memberId);
		builder.append(", ");
		builder.append(memberPw);
		builder.append(", ");
		builder.append(name);
		builder.append(", ");
		builder.append(phone);
		builder.append(", ");
		builder.append(email);
		builder.append(", ");
		builder.append(entryDate);
		builder.append(", ");
		builder.append(grade);
		builder.append(", ");
		builder.append(point);
		builder.append(", ");
		builder.append(manager);
		return builder.toString();
	}

	
}















