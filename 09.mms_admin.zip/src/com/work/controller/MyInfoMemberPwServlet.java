package com.work.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.work.model.biz.MemberManagement;

/**
 * Servlet implementation class MyInfoMemberPwServlet
 */
public class MyInfoMemberPwServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * # 비밀번호 변경 요청
	 * 
	 * 1. 세션 : 아이디가져오기
	 * 2. 요청 입력데이터 : 기존암호, 변경암호 가져오기
	 * 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		
		String memberId = (String)session.getAttribute("memberId");
		
		// 로그인 하지 않은 사용자에 대한 오류처리
		if (session == null || memberId == null) {
			// 비밀번호 변경 실패 응답 설정 => 페이지 이동
			request.setAttribute("message", "로그인 전용 서비스입니다. 로그인 후 이용하시기 바랍니다.");
			
			// 포워드 페이지 이동
			RequestDispatcher dispatcher = request.getRequestDispatcher("/fail.jsp");
			dispatcher.forward(request, response);				
			return;
		}
		
		String memberPw = request.getParameter("memberPw");
		String modifyMemberPw = request.getParameter("modifyMemberPw");
		
		MemberManagement mngr = new MemberManagement();
		
		boolean result = mngr.myInfoMemberPw(memberId, memberPw, modifyMemberPw); 
		
		if (result) {
			// 비밀번호 변경 성공시 응답 => 내정보 조회 요청
			response.sendRedirect("myInfo");
			
//			// 비밀번호 변경 성공 응답 설정 => 페이지 이동
//			request.setAttribute("message", "비빌번호 변경이 완료되었습니다.");
//			
//			// 포워드 페이지 이동
//			RequestDispatcher dispatcher = request.getRequestDispatcher("/message.jsp");
//			dispatcher.forward(request, response);		
		} else {
			// 비밀번호 변경 실패 응답 설정 => 페이지 이동
			request.setAttribute("message", "비빌번호 변경이 실패하였습니다. 정보를 다시 확인하시기 바랍니다.");
			
			// 포워드 페이지 이동
			RequestDispatcher dispatcher = request.getRequestDispatcher("/message.jsp");
			dispatcher.forward(request, response);				
		}
	}

}
