package com.work.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.work.model.biz.MemberManagement;
import com.work.model.dto.Member;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	/**
	 * ## 로그인 요청 서비스
	 * 3. 서비스 재정의 순서
		(1) 요청 객체에 대한 한글 인코딩 설정
			=> 요청시 전달받은 데이터 가져오기
			
		(2) 응답위한 mime type 설정
		(3) 응답위한 출력스트림 객체 생성
		(4) 출력스트림을 통해서 동적 페이지 전송
		(5) 출력스트림 자원해제
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 1
		request.setCharacterEncoding("utf-8");
		// login.jsp => name="memberId"
		// 아이디 가져오기
		String memberId = request.getParameter("memberId").trim();
		// 비밀번호 가져오기
		String memberPw = request.getParameter("memberPw").trim();
		
		// 회원테이블에 대한 crud 사용하기 위한 객체 생성
		//MemberDao dao = new MemberDao();
		
		// 회원 업무처리 로직을 담당하는 객체 생성
		MemberManagement mngr = new MemberManagement();
	
		// 업무처리 로직 에게 로그인 요청 
		Member dto = mngr.login(memberId, memberPw);
		
		// 로그인 성공 : mainService.jsp
		// 로그인 실패 : fail.jsp
		
		if (dto != null) { 			
			// 로그인 성공 : 
			// 1. HttpSession 객체 신규 생성
			HttpSession session = request.getSession(true);
			
			// 2. 세션객체에 필요로하는 상태정보 설정 : setAttribute(key, object) : 로그인 ~ 로그아웃 할때까지 정보 유지
			session.setAttribute("dto", dto);
			
			session.setAttribute("memberId", dto.getMemberId());
			session.setAttribute("name", dto.getName());
			session.setAttribute("grade", dto.getGrade());
			
			// 3. 페이지 이동 : redirect
			response.sendRedirect("mainService.jsp");
			
		} else {
			// 로그인 실패
			//response.sendRedirect("fail.jsp");
			
			// 응답 메세지 설정
			request.setAttribute("message", "사용자 인증 실패하였습니다. 회원 정보를 다시 확인하시기 바랍니다.");
			
			// 포워드 페이지 이동
			RequestDispatcher dispatcher = request.getRequestDispatcher("/fail.jsp");
			dispatcher.forward(request, response);		
		}
	}

}
