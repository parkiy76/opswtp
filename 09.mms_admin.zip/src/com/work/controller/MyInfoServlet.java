package com.work.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.work.model.biz.MemberManagement;
import com.work.model.dto.Member;

/**
 * Servlet implementation class MyInfoServlet
 */
public class MyInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * ## 로그인한 회원 내정보 조회
	 * 1. 기존 세션객체 가져오기
	 * 2. 세션에 설정한 로그인인증받은 회원의 아이디 정보 가져오기
	 * 3. Model(Biz) 객체에게 회원정보 상세조회 요청하기
	 * 4. 회원정보 상세조회 성공 응답위한 설정하기
	 * 5. 회원정보 성공 응답페에지 포워드 이동하기
	 * 	=> myInfo.jsp
	 * 
	 * 6. 회원정보 응답결과가 null 오류 페이지 설정하기 
	 * 	=> 오류 페이지 이동하기
	 * 	=> message.jsp
	 * 
	 * 7. 로그인하지 않은 사용자 응답결과 오류 페이지 설정하기 => 오류 페이지 이동하기
	 * 	=> fail.jsp
	 * 
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session != null) {
			String memberId = (String)session.getAttribute("memberId");
			if (memberId != null) {
				
				MemberManagement mngr = new MemberManagement();
				Member dto = mngr.getMember(memberId);
				
				if (dto != null) {
					// 내정보 상세조회 응답 성공 위한 설정
					request.setAttribute("dto", dto);
					
					// 내정보 상세조회 페이지 포워드 이동 :myInfo.jsp
					RequestDispatcher dispatcher = request.getRequestDispatcher("/myInfo.jsp");
					dispatcher.forward(request, response);		

				} else {
					// 로그인 한 회원의 내정보 조회 실패 응답 설정 : message.jsp
					request.setAttribute("message", "내정보 조회시에 오류가 발생했습니다. 다시 확인하시기 바랍니다.");
					
					// 내정보 조회 실패 응답페이지 포워드 이동
					RequestDispatcher dispatcher = request.getRequestDispatcher("/message.jsp");
					dispatcher.forward(request, response);		
				}
				
			} else {
				// 로그인하지 않은 회원 처리
				request.setAttribute("message", "회원전용 서비스입니다. 사용자 인증 후 이용하시기 바랍니다.");
				RequestDispatcher dispatcher = request.getRequestDispatcher("/fail.jsp");
				dispatcher.forward(request, response);	
			}
			
		} else {
			// 로그인하지 않은 회원 처리
			request.setAttribute("message", "회원전용 서비스입니다. 사용자 인증 후 이용하시기 바랍니다.");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/fail.jsp");
			dispatcher.forward(request, response);	
		}
	}

}
