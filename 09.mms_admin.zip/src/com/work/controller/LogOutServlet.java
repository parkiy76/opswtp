package com.work.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LogOutServlet
 */
public class LogOutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * # 로그아웃
	 * 1. 기존 세션객체 가져오기
	 * 2. 기존 세션객체 설정한 세션정보가 존재하면 세션정보 삭제 : removeAttribute(key)
	 * 3. 기존 세션객체 죽이기 : invalidate()
	 * 4. 로그아웃 성공 응답페이지 이동 : 시작페이지 이동 redirect
 	 * 
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session != null) {
			session.removeAttribute("dto");
			session.removeAttribute("memberId");
			session.removeAttribute("name");
			session.removeAttribute("grade");
			
			session.invalidate();
			response.sendRedirect("index.jsp");
		} else {
			request.setAttribute("message", "로그아웃 요청은 로그인 후 이용하시기 바랍니다.");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/fail.jsp");
			dispatcher.forward(request, response);		
		}
	}

}








