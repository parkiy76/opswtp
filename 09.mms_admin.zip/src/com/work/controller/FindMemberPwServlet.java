package com.work.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.work.model.dao.MemberDao;

/**
 * Servlet implementation class FindMemberPwServlet
 */
public class FindMemberPwServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");

		String memberId = request.getParameter("memberId");
		String name = request.getParameter("name");
		String phone = request.getParameter("phone");
		
		MemberDao dao = new MemberDao();
		String memberPw = dao.selectFindMemberPw(memberId, name, phone);
		
		if (memberPw != null) {
			request.setAttribute("message", name + "님의 임시발급 변경암호입니다. 로그인 후 암호를 변경하시기 바랍니다. : " + memberPw);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/result.jsp");
			dispatcher.forward(request, response);		
		} else {
			request.setAttribute("message", name + "님의 정보를 다시 확인하시기 바랍니다.");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/fail.jsp");
			dispatcher.forward(request, response);		
		}
	}

}
