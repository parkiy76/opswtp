package com.work.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.work.model.biz.MemberManagement;
import com.work.model.dto.Member;

/**
 * Servlet implementation class JoinSaveServlet
 */
public class JoinSaveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * ## 회원가입요청저장
	 * 1. 요청객체 한글 인코딩설정
	 * 2. 요청객체 정보 가져오기: 요청페이지참고 : 회원가입페이지(join.jsp)
	 * 
	 * 3. 데이터 검증 : 필수입력항목
	 * 
	 * 4. Model(Biz) 요청의뢰 : MemberMangement => 메서드명(Member) : boolean
	 * 5. 응답결과 받아서 응답위한 설정 : boolean
	 * 
	 * 6. 응답페이지 이동
	 * 		성공 : 성공메세지출력 => 로그인요청
	 * 		실패 : 
	 * 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		String memberId = request.getParameter("memberId").trim();
		String memberPw = request.getParameter("memberPw");
		String name = request.getParameter("name");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		
		System.out.println(memberId + ", " + memberPw + ", " + name + ", " + phone + ", " + email);
		
		if (memberId == null || memberId.trim().length() == 0 ||
			memberPw == null || memberPw.trim().length() == 0 ||	
			name == null || name.trim().length() == 0 ||
			phone == null || phone.trim().length() == 0 ||
			email == null || email.trim().length() == 0) {
			
			request.setAttribute("message", "회원등록 필수입력데이터를 미입력하셨습니다. 회원정보를 입력하시기 바랍니다.");
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("/fail.jsp");
			dispatcher.forward(request, response);	
			return;
		}
		
		Member dto = new Member(memberId.trim(), memberPw.trim(), name.trim(), phone.trim(), email.trim());
		MemberManagement mngr = new MemberManagement();
		boolean result = mngr.addMember(dto);
		
		if (result) { // 회원가입 성공 응답처리		
			//response.sendRedirect("/login.jsp");
			
			request.setAttribute("message", "회원가입이 정상 처리되었습니다. 로그인 후 회원전용 서비스를 이용하시기 바랍니다.");
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("/result.jsp");
			dispatcher.forward(request, response);	
				
		} else {	// 회원가입 실패 응답처리
			request.setAttribute("message", "회원가입이 정상적으로 이루어지지 않았습니다. 다시 확인하시기 바랍니다.");
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("/fail.jsp");
			dispatcher.forward(request, response);	
		}
	}

}
