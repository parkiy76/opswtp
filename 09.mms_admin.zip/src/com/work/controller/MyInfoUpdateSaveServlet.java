package com.work.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.work.model.biz.MemberManagement;

/**
 * Servlet implementation class MyInfoUpdateSaveServlet
 */
public class MyInfoUpdateSaveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * # 내정보 변경 저장
	 * 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		String memberId = (String)session.getAttribute("memberId");
		
		if (session == null || memberId == null) {
			request.setAttribute("message", "로그인 전용 서비스입니다. 로그인 후 이용하시기 바랍니다.");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/fail.jsp");
			dispatcher.forward(request, response);				
			return;
		}
		
		request.setCharacterEncoding("utf-8");
		String memberPw = request.getParameter("memberPw");
		String name = request.getParameter("name");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		
		MemberManagement mngr = new MemberManagement();
		
		boolean result = mngr.setMyInfo(memberId, memberPw, name, phone, email); 
		
		if (result) {
			response.sendRedirect("myInfo");
		} else {
			request.setAttribute("message", "내정보 변경시에 오류가 발생했습니다. 정보를 다시 확인하시기 바랍니다.");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/message.jsp");
			dispatcher.forward(request, response);				
		}
	}

}
