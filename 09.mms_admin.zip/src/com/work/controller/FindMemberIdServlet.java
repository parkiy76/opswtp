package com.work.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.work.model.biz.MemberManagement;

/**
 * Servlet implementation class FindMemberIdServlet
 */
public class FindMemberIdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		String name = request.getParameter("name");
		String phone = request.getParameter("phone");
		
		//MemberDao dao = new MemberDao();
		MemberManagement mngr = new MemberManagement();
		
		String memberId = mngr.getFindMemberId(name, phone);
		
		if (memberId != null) {
			request.setAttribute("message", name + "님의 아이디 정보입니다 : " + memberId);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/result.jsp");
			dispatcher.forward(request, response);		
		} else {
			request.setAttribute("message", name + "님의 정보를 다시 확인하시기 바랍니다.");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/fail.jsp");
			dispatcher.forward(request, response);		
		}
	}

}
