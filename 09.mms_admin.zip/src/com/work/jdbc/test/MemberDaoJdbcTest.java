package com.work.jdbc.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.work.model.dto.Member;

/*
	예제코드 : JDBC Programming 
*/
public class MemberDaoJdbcTest {
	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = "jdbc:oracle:thin:@127.0.0.1:1521:XE";
	private String user = "student";
	private String password = "tiger";
		
	public Connection getConnection() {
		try {
			return DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public Member login(String memberId, String memberPw) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			// 1. driver loading
			try {
				Class.forName(driver);
			} catch (ClassNotFoundException e) {
				System.out.println("JDBC Driver 로딩 오류");
				e.printStackTrace();
			}
			
			// 2. db 연결
			//conn = DriverManager.getConnection(url, user, password);
			conn = getConnection();
			
			// 3. 로그인 전용 통로개설
			String sql = "SELECT * FROM MEMBER WHERE MEMBER_ID=? AND MEMBER_PW=?";
			pstmt = conn.prepareStatement(sql);
			
			// 3. 로그인 전용통로 ? 매핑되는 값 설정
			pstmt.setString(1, memberId);	// user01 => 'user01'
			pstmt.setString(2, memberPw);
			
			// 4. sql 수행요청
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				//String memberId = rs.getNString("member_id");
				//String memberPw = rs.getNString("member_pw");
				String name = rs.getString("name");
				String phone = rs.getString("phone");
				String email = rs.getString("email");
				String entryDate = rs.getString("entry_Date");
				String grade = rs.getString("grade");
				int point = rs.getInt("point");
				String manager = rs.getString("manager");
				
				Member dto = new Member(memberId, memberPw, name, phone, email, entryDate, grade, point, manager);
				return dto;
			} else {
				return null;
			}
			
		} catch(SQLException e) {
			System.out.println("로그인 오류");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return null;
	}
	
	/** 회원 내정보 상세조회 */
	public Member selectOne(String memberId) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from member where member_id = ?";
		try {
			//conn = ds.getConnection();
			conn = DriverManager.getConnection(url, user, password);
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, memberId);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				//String memberId = rs.getString("member_id");
				String memberPw = rs.getString("member_pw");
				String name = rs.getString("name");
				String phone = rs.getString("phone");
				String email = rs.getString("email");
				String entryDate = rs.getString("entry_Date");
				String grade = rs.getString("grade");
				int point = rs.getInt("point");
				String manager = rs.getString("manager");
				
				return new Member(memberId, memberPw, name, phone, email, entryDate, grade, point, manager);
			} 
			
		} catch(SQLException e) {
			System.out.println("내정보조회 오류");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return null;		
	}
	
	public boolean updateMemberPw(String memberId, String memberPw, String modifyMemberPw) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "update member set member_pw=? where member_id=? and member_pw=?";
		
		try {
			conn = getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, modifyMemberPw);
			pstmt.setString(2, memberId);
			pstmt.setString(3, memberPw);
			
			int rows = pstmt.executeUpdate();
			
			if (rows == 1) {
				return true;
			} 
			
		} catch(SQLException e) {
			System.out.println("암호변경 오류");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return false;
	}
	
	
	public ArrayList<Member> selectList() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM MEMBER";
		ArrayList<Member> list = new ArrayList<Member>();
		
		try {
			conn = getConnection();
			
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				String memberId = rs.getString("member_id");
				String memberPw = rs.getString("member_pw");
				String name = rs.getString("name");
				String phone = rs.getString("phone");
				String email = rs.getString("email");
				String entryDate = rs.getString("entry_Date");
				String grade = rs.getString("grade");
				int point = rs.getInt("point");
				String manager = rs.getString("manager");
				
				list.add(new Member(memberId, memberPw, name, phone, email, entryDate, grade, point, manager));
			} 
			
		} catch(SQLException e) {
			System.out.println("내정보조회 오류");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return list;		
	}
	
	public static void main(String[] args) {
		MemberDaoJdbcTest dao = new MemberDaoJdbcTest();
		Member dto = null;
		
//		Member dto = dao.login(args[0], args[1]);
//		System.out.println(dto);
		
//		System.out.println("회원상세조회 테스트");
//		dto = dao.selectOne("user01");
//		System.out.println(dto);
	
//		System.out.println("암호변경 테스트 : user01, password01, happyday2020");
//		boolean result = dao.updateMemberPw("user01", "password01", "happyday2020");
//		if (result) {
//			System.out.println("암호변경 성공");
//		} else {
//			System.out.println("암호변경 실패");
//		}
		
		System.out.println("전체회원조회");
		ArrayList<Member> list = dao.selectList();
		
		for (int index = 0; index < list.size(); index++) {
			dto = list.get(index);
			System.out.println(dto);
		}
	}
	
}














