/* 회원 게시글 관리 SQL 스크립트 
    -- MMS_DDL.SQL 
    -- MMS_DML.SQL 
    -- MMS_init.SQL 
*/

-- ################################################
--  MMS_DDL.SQL 
-- ################################################
-- 테이블 삭제
DROP TABLE NOTICE cascade constraints purge;
DROP TABLE MEMBER cascade constraints purge;

-- 테이블 생성
-- 1. 부모테이블 : 회원
create table member (
	member_id varchar2(20), 
	member_pw varchar2(20) not null, 
	name  varchar2(30) not null,
	phone  varchar2(13) not null, 
	email varchar2(40) not null,	
	entry_date  varchar2(10) not null, 
	grade  varchar2(1) not null,
	point number(6),
	manager  varchar2(30)  
);

-- 2. 자식테이블 : 게시글
create table notice (
	notice_no number(3),
	title varchar2(100) not null,
	contents varchar2(500),
	write_date date,
	member_id varchar2(20),
	hit_count number default 0
);

-- 테이블 생성 후 제약 추가지정
-- 1. 부모테이블 : 회원
-- PK
alter table member
add constraint pk_member_memberid primary key (member_id);

-- grade : G, S, A
alter table member
add constraint ck_member_grade check (grade in ('G', 'S', 'A'));

-- point : 100,000 이하
alter table member
add constraint ck_member_point check (point <= 100000);

-- 2. 자식테이블 : 게시글
-- pk
alter table notice
add constraint pk_notice_noticeno primary key (notice_no);

-- fk
alter table notice
add constraint fk_notice_memberid foreign key(member_id) references member(member_id);

-- 게시글 번호 사용 위한 시퀀스 객체 삭제 및 생성
drop sequence seq_notice_no;
create sequence seq_notice_no maxvalue 999 nocycle;

-- 테이블 구조 조회
desc member;
desc notice;

/* ################################################
	테이블, 컬럼에 대한 주석문 추가
	
	--테이블 Comment 설정
	COMMENT ON TABLE [테이블명] IS [Comment];

	--컬럼 Comment 설정
	COMMENT ON COLUMN [테이블명].[컬럼명] IS '[Comment]';

	-- 테이블 주석 데이터 딕셔너리 테이블
	USER_TAB_COMMENTS

	-- 컬럼 주석 데이터 딕셔너리 테이블
	USER_COL_COMMENTS 
################################################ */

-- 회원 테이블 주석
comment ON TABLE member IS '회원정보 테이블, 아이디,비밀번호,이름,휴대폰,이메일,가입일,등급,포인트,담당자 정보로 구성';

-- 회원 컬럼 주석
comment ON COLUMN member.member_id IS '회원식별키, 회원아이디, 최소6자리 ~ 20자리 이내'
comment ON COLUMN member.member_pw IS '회원 비밀번호, 필수, 최소 8자리 ~ 20자리 이내'
comment ON COLUMN member.name IS '회원 이름, 필수, 최소 2자리 ~ 30자리 이내'
comment ON COLUMN member.phone IS '회원 휴대폰, 필수, 010-1234-1234 형식'
comment ON COLUMN member.email IS '회원 이메일, 필수'
comment ON COLUMN member.entry_date IS '회원 가입일, 가입시 현재날짜, 년도4자리.월2자리.일2자리 형식';
comment ON COLUMN member.grade IS '회원 등급, 일반(G), 우수(S), 관리자(A), 회원가입시 일반(G)';
comment ON COLUMN member.point IS '회원 포인트, 일반회원에게 부여'
comment ON COLUMN member.manager IS '회원 담당자이름, 우수회원에게 배정됨, 일반회원 포인트 100,000 이상시 우수회원 등업';

-- 테이블 주석 조회 : desc USER_TAB_COMMENTS
SELECT  table_name, table_type, comments FROM USER_TAB_COMMENTS WHERE comments IS NOT NULL; 

-- 테이블 컬럼 주석 조회 : desc USER_COL_COMMENTS
SELECT table_name, column_name, comments FROM USER_COL_COMMENTS WHERE comments IS NOT NULL; 


