/* 회원 게시글 관리 SQL 스크립트 
    -- MMS_DDL.SQL 
    -- MMS_DML.SQL 
    -- MMS_init.SQL 
*/

-- ################################################
--  MMS_DML.SQL 
-- ################################################


-- 기존 레코드 전체 삭제
TRUNCATE TABLE notice;
TRUNCATE TABLE member;

-- 초기화 레코드 추가
-- 회원등록 
insert into member(member_id, member_pw, name, phone, email, entry_date, grade, point)
values('user01', 'password01', '홍길동', '010-1234-1000', 'user01@work.com', '2020.01.20', 'G', 10000);

insert into member
values('user02', 'password02', '강감찬', '010-1234-2000', 'user02@work.com', '2020.02.21', 'G', 50000, null);

insert into member
values('user03', 'password03', '이순신', '010-1234-3000', 'user03@work.com', '2020.03.22', 'S', null, '강동원');

insert into member
values('user04', 'password04', '김유신', '010-1234-4000', 'user04@work.com', '2020.04.23', 'S', null, '아이유');

insert into member
values('user05', 'password05', '유관순', '010-1234-5000', 'user05@work.com', '2020.05.24', 'A', null, null);

commit;

-- insert into member values(?, ?, ?, ?, ?, ?, ?, ?, ?)


-- 게시글 초기레코드 : 게시글번호 시퀀스객체 이용
insert into notice(notice_no, title, contents, write_date, member_id)
values(set_notice_no.nextval, '호우 경보 안내', '서울 중부, 충남 집중호우 유의하시기 바랍니다.', to_date('2020.07.21', 'yyyy.mm.dd'), 'user01');

insert into notice
values(set_notice_no.nextval, '데이터 베이스 실습', '데이터 베이스 조인 연습하기 바랍니다.', to_date('2020.07.22', 'yyyy.mm.dd'), 'user02', 3);

insert into notice
values(set_notice_no.nextval, '서블릿 웹 프로그래밍', '자바 기반의 동적 웹 어플리케이션 기술입니다', to_date('2020.08.01', 'yyyy.mm.dd'), 'user03', 10);

insert into notice
values(set_notice_no.nextval, '2학기 강의일정표', '2학기 강의 일정표가 변경되었습니다.', to_date('2020.08.02', 'yyyy.mm.dd'), 'user04', 2);

insert into notice
values(set_notice_no.nextval, '우산 빌려드립니다', '2학기 수업중인 학생들에게 본관 입구에서 우산을 빌려드립니다.', SYSDATE, 'user02', 1);

insert into notice
values(set_notice_no.nextval, '데이터 베이스 과제(냉무)', null, SYSDATE, 'user02', 0);

commit;

-- 전체회원 조회
SELECT * FROM MEMBER;

-- ## 회원관리 기능 SQL 구문 : 회원등록, 로그인, 아이디찾기, 비밀번호찾기, 내정보조회, 비밀번호변경, 회원탈퇴
-- 회원등록
insert into member(member_id, member_pw, name, phone, email, entry_date, grade, point)
values('test01', 'password01', '테스터1', '010-3333-7777', 'test01@work.com', '2020.08.04', 'G', 10000);


-- 로그인(아이디, 비밀번호) : 해당회원정보 반환
SELECT * 
FROM MEMBER
WHERE MEMBER_ID='test01' AND MEMBER_PW='password01';

-- SELECT * FROM MEMBER WHERE MEMBER_ID=? AND MEMBER_PW=?


-- 아이디 찾기(이름, 휴대폰) : 해당회원 아이디 반환
SELECT MEMBER_ID 
FROM MEMBER
WHERE NAME='홍길동' AND PHONE='010-1234-1000';

-- SELECT MEMBER_ID FROM MEMBER WHERE NAME=? AND PHONE=?

-- 비밀번호변경(아이디, 기존암호, 변경암호)
update member
set member_pw='happyday2020'
where member_id='test01' and member_pw='password01';

-- 비밀번호찾기
SELECT MEMBER_Pw 
FROM MEMBER
WHERE MEMBER_ID='test01' AND NAME='테스터1' AND PHONE='010-3333-7777';

-- 비밀번호 임시발급암호 변경
-- 임시발급암호
select to_char(sysdate, 'mmyyddhhssmi') from dual;

update member set member_pw=(select to_char(sysdate, 'mmyyddhhssmi') from dual)
where MEMBER_ID='test01' AND NAME='테스터1' AND PHONE='010-3333-7777';

-- 임시발급 변경암호 조회
SELECT MEMBER_Pw 
FROM MEMBER
WHERE MEMBER_ID='test01' AND NAME='테스터1' AND PHONE='010-3333-7777';

-- 내정보조회(회원상세조회)
select * 
from member
where member_id = 'test01';

-- 회원탈퇴
delete member
where member_id='test01';


-- ## 게시글관리 기능 : 게시글등록, 게시글 상세조회, 게시글 전체조회, 게시글 변경, 게시글 삭제

-- 전체게시글 조회
SELECT * FROM NOTICE;

-- 게시글등록
insert into notice
values(set_notice_no.nextval, '자바 웹어플리케이션 개발', '서블릿 및 JSP 활용한 동적 웹 어플리케이션 개발과정입니다.', SYSDATE, 'user01', 0);

-- 게시글 상세조회
select * 
from notice 
where notice_no = 1;


-- 게시글 변경
update notice
set title='호우 경보 해제 안내', contents='호우 경보를 해제합니다. 호우로 인한 주위 환경을 점검하시기 바랍니다.'
where notice_no = 1;


-- 게시글 삭제
delete notice
where notice_no=1;

-- 게시글 다중 조건 조회
-- 제목
select * 
from notice
where title like '%우산%';

-- 내용
select * 
from notice
where contents like '%2학기%';

-- 제목 + 내용
select * 
from notice
where title like '%2학기%' or contents like '%2학기%';

-- 작성자
select *
from notice
where member_id='user02';







