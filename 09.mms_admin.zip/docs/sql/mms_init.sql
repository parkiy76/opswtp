/* 회원 게시글 관리 SQL 스크립트 
    -- MMS_DDL.SQL 
    -- MMS_DML.SQL 
    -- MMS_init.SQL 
*/

-- ################################################
--  MMS_init.SQL : 초기화 레코드 수행 스크립트 파일
-- ################################################


-- 기존 레코드 전체 삭제
TRUNCATE TABLE notice;
TRUNCATE TABLE member;

-- 초기화 레코드 추가
-- 회원등록 
insert into member(member_id, member_pw, name, phone, email, entry_date, grade, point)
values('user01', 'password01', '홍길동', '010-1234-1000', 'user01@work.com', '2020.01.20', 'G', 10000);

insert into member
values('user02', 'password02', '강감찬', '010-1234-2000', 'user02@work.com', '2020.02.21', 'G', 50000, null);

insert into member
values('user03', 'password03', '이순신', '010-1234-3000', 'user03@work.com', '2020.03.22', 'S', null, '강동원');

insert into member
values('user04', 'password04', '김유신', '010-1234-4000', 'user04@work.com', '2020.04.23', 'S', null, '아이유');

insert into member
values('user05', 'password05', '유관순', '010-1234-5000', 'user05@work.com', '2020.05.24', 'A', null, null);

commit;

-- 게시글 초기레코드 : 게시글번호 시퀀스객체 이용
insert into notice(notice_no, title, contents, write_date, member_id)
values(set_notice_no.nextval, '호우 경보 안내', '서울 중부, 충남 집중호우 유의하시기 바랍니다.', to_date('2020.07.21', 'yyyy.mm.dd'), 'user01');

insert into notice
values(set_notice_no.nextval, '데이터 베이스 실습', '데이터 베이스 조인 연습하기 바랍니다.', to_date('2020.07.22', 'yyyy.mm.dd'), 'user02', 3);

insert into notice
values(set_notice_no.nextval, '서블릿 웹 프로그래밍', '자바 기반의 동적 웹 어플리케이션 기술입니다', to_date('2020.08.01', 'yyyy.mm.dd'), 'user03', 10);

insert into notice
values(set_notice_no.nextval, '2학기 강의일정표', '2학기 강의 일정표가 변경되었습니다.', to_date('2020.08.02', 'yyyy.mm.dd'), 'user04', 2);

insert into notice
values(set_notice_no.nextval, '우산 빌려드립니다', '2학기 수업중인 학생들에게 본관 입구에서 우산을 빌려드립니다.', SYSDATE, 'user02', 1);

insert into notice
values(set_notice_no.nextval, '데이터 베이스 과제(냉무)', null, SYSDATE, 'user02', 0);

commit;

-- 전체회원 조회
SELECT * FROM MEMBER;

-- 전체게시글 조회
select * from notice;
